/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

/* ************************************************************************

#resource(filesizedemo.image:image)

// List all static resources that should be copied into the build version,
// if the resource filter option is enabled (default: disabled)
#embed(qx.icontheme/32/status/dialog-information.png)
#embed(filesizedemo.image/test.png)

************************************************************************ */

/**
 * Your filesizedemo application
 */
qx.Class.define("filesizedemo.Application",
{
  extend : qx.application.Gui,




  /*
  *****************************************************************************
     MEMBERS
  *****************************************************************************
  */

  members :
  {
    /**
     * TODOC
     *
     * @type member
     */
    main : function()
    {
      this.base(arguments);
	  //inspector.Inspector.init();
      // Define alias for filesizedemo resource path
      qx.io.Alias.getInstance().add("filesizedemo", qx.core.Setting.get("filesizedemo.resourceUri"));

	  var ex1 = 5000;
	  var ex2 = 500000;
	  var ex3 = 50000000;
	  var ex4 = 5000000000;

      // Create button
      var button1 = new qx.ui.form.Button("Process " + ex1, "filesizedemo/image/test.png");

      // Set button location
      button1.setTop(20);
      button1.setLeft(50);

      // Add button to document
      button1.addToDocument();

      // Attach a tooltip
      button1.setToolTip(new qx.ui.popup.ToolTip("example 1", "icon/32/status/dialog-information.png"));

	  var filesizeFormat1 = new filesize.FilesizeFormat();
	  
      // Add an event listener
      button1.addEventListener("execute", function(e) {
        alert(ex1 + " becomes " + filesizeFormat1.format(ex1));
      });
      
      
      // Create button
      var button2 = new qx.ui.form.Button("Process " + ex2, "filesizedemo/image/test.png");

      // Set button location
      button2.setTop(20);
      button2.setLeft(250);

      // Add button to document
      button2.addToDocument();

      // Attach a tooltip
      button2.setToolTip(new qx.ui.popup.ToolTip("example 2", "icon/32/status/dialog-information.png"));

	  var filesizeFormat1 = new filesize.FilesizeFormat();

      // Add an event listener
      button2.addEventListener("execute", function(e) {
        alert(ex2 + " becomes " + filesizeFormat1.format(ex2));
      });
      
      // Create button
      var button3 = new qx.ui.form.Button("Process " + ex3, "filesizedemo/image/test.png");

      // Set button location
      button3.setTop(20);
      button3.setLeft(450);

      // Add button to document
      button3.addToDocument();

      // Attach a tooltip
      button3.setToolTip(new qx.ui.popup.ToolTip("example 3", "icon/32/status/dialog-information.png"));

	  var filesizeFormat1 = new filesize.FilesizeFormat();

      // Add an event listener
      button3.addEventListener("execute", function(e) {
        alert(ex3 + " becomes " + filesizeFormat1.format(ex3));
      });

      // Create button
      var button4 = new qx.ui.form.Button("Process " + ex4, "filesizedemo/image/test.png");

      // Set button location
      button4.setTop(20);
      button4.setLeft(650);

      // Add button to document
      button4.addToDocument();

      // Attach a tooltip
      button4.setToolTip(new qx.ui.popup.ToolTip("example 4", "icon/32/status/dialog-information.png"));

	  var filesizeFormat1 = new filesize.FilesizeFormat();

      // Add an event listener
      button4.addEventListener("execute", function(e) {
        alert(ex4 + " becomes " + filesizeFormat1.format(ex4));
      });   
  
	  // table model
	  var tableModel = new qx.ui.table.model.Simple();
	  tableModel.setColumns([ "ID", "A filesize", "A date", "Boolean test" ]);
	  var rowData = [];
	  var now = new Date().getTime();
	  var dateRange = 600 * 24 * 60 * 60 * 1000; // 400 days
	    
	  for (var row = 0; row < 20; row++) {
	    var date = new Date(now + Math.random() * dateRange - dateRange / 2);
	    //var date = now + Math.random() * dateRange - dateRange / 2;
	    rowData.push([ row, Math.pow(Math.random(),7) * 1000000000, date, (Math.random() > 0.5) ]);
	  }
	  tableModel.setData(rowData);
	  tableModel.setColumnEditable(1, true);
	  tableModel.setColumnEditable(2, true);
	    
	  myFilesizeFormat = new qx.util.format.FilesizeFormat(); 
	
	  // table
	  var table = new qx.ui.table.Table(tableModel);
	    
	  DateFormatA = new qx.util.format.DateFormat("MMM dd, yyyy");
	  DateRendererA = new qx.ui.table.cellrenderer.Date();
	  DateRendererA.setDateFormat(DateFormatA);    
	     
	  FilesizeFormatB = new qx.util.format.FilesizeFormat();
	  FilesizeRendererB = new qx.ui.table.cellrenderer.Filesize();
	  FilesizeRendererB.setFilesizeFormat(FilesizeFormatB);
	    
	  with (table) {
	    set({ left:10, top:90, width:440, bottom:30, border:"inset-thin" });
	    setMetaColumnCounts([1, -1]);
	    getSelectionModel().setSelectionMode(qx.ui.table.selection.Model.MULTIPLE_INTERVAL_SELECTION);
	    getTableColumnModel().setDataCellRenderer(3, new qx.ui.table.cellrenderer.Boolean());
	    
	    getTableColumnModel().setDataCellRenderer(2, DateRendererA);
	    getTableColumnModel().setDataCellRenderer(1, FilesizeRendererB);
	    getTableColumnModel().setDataCellRenderer(0, new qx.ui.table.cellrenderer.Number());
		
		setColumnWidth(0, 80);
	    setColumnWidth(1, 120);
	    setColumnWidth(2, 120);
	  };
	
	  qx.ui.core.ClientDocument.getInstance().add(table);
    },

    /**
     * TODOC
     *
     * @type member
     */
    close : function()
    {
      this.base(arguments);

      // Prompt user
      // return "Do you really want to close the application?";
    },


    /**
     * TODOC
     *
     * @type member
     */
    terminate : function() {
      this.base(arguments);
    }
  },




  /*
  *****************************************************************************
     SETTINGS
  *****************************************************************************
  */

  settings : {
    "filesizedemo.resourceUri" : "./resource"
  }
});
