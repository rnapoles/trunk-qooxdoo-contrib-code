/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("explorer.theme.Appearance",
{
  extend : qx.theme.modern.Appearance,

  appearances :
  {
  }
});