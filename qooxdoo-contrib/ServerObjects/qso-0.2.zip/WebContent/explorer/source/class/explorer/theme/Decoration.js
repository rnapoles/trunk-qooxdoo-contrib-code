/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("explorer.theme.Decoration",
{
  extend : qx.theme.modern.Decoration,

  decorations :
  {
  }
});