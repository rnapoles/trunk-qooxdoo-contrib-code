/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("explorer.theme.Theme",
{
  meta :
  {
    color : explorer.theme.Color,
    decoration : explorer.theme.Decoration,
    font : explorer.theme.Font,
    icon : qx.theme.icon.Tango,
    appearance : explorer.theme.Appearance
  }
});