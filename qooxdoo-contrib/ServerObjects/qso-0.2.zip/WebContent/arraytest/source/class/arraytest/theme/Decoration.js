/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("arraytest.theme.Decoration",
{
  extend : qx.theme.modern.Decoration,

  decorations :
  {
  }
});