/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("arraytest.theme.Theme",
{
  meta :
  {
    color : arraytest.theme.Color,
    decoration : arraytest.theme.Decoration,
    font : arraytest.theme.Font,
    icon : qx.theme.icon.Tango,
    appearance : arraytest.theme.Appearance
  }
});