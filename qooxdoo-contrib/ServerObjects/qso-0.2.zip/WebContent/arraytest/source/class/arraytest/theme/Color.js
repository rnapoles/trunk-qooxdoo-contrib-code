/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("arraytest.theme.Color",
{
  extend : qx.theme.modern.Color,

  colors :
  {
  }
});