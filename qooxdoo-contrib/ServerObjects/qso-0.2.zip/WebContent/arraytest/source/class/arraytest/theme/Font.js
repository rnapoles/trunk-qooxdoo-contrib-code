/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("arraytest.theme.Font",
{
  extend : qx.theme.modern.Font,

  fonts :
  {
  }
});