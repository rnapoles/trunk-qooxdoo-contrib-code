/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("arraytest.theme.Appearance",
{
  extend : qx.theme.modern.Appearance,

  appearances :
  {
  }
});