/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("demoapp.theme.Appearance",
{
  extend : qx.theme.modern.Appearance,

  appearances :
  {
  }
});