/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("demoapp.theme.Font",
{
  extend : qx.theme.modern.Font,

  fonts :
  {
  }
});