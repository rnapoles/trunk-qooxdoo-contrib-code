/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("demoapp.theme.Decoration",
{
  extend : qx.theme.modern.Decoration,

  decorations :
  {
  }
});