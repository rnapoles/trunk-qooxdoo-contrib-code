/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("demoapp.theme.Theme",
{
  meta :
  {
    color : demoapp.theme.Color,
    decoration : demoapp.theme.Decoration,
    font : demoapp.theme.Font,
    icon : qx.theme.icon.Tango,
    appearance : demoapp.theme.Appearance
  }
});