/* ************************************************************************

   Copyright:

   License:

   Authors:

************************************************************************ */

qx.Theme.define("demoapp.theme.Color",
{
  extend : qx.theme.modern.Color,

  colors :
  {
  }
});