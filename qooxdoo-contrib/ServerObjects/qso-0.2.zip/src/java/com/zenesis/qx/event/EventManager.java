/**
 * ************************************************************************
 * 
 *    server-objects - a contrib to the Qooxdoo project that makes server 
 *    and client objects operate seamlessly; like Qooxdoo, server objects 
 *    have properties, events, and methods all of which can be access from
 *    either server or client, regardless of where the original object was
 *    created.
 * 
 *    http://qooxdoo.org
 * 
 *    Copyright:
 *      2010 Zenesis Limited, http://www.zenesis.com
 * 
 *    License:
 *      LGPL: http://www.gnu.org/licenses/lgpl.html
 *      EPL: http://www.eclipse.org/org/documents/epl-v10.php
 *      
 *      This software is provided under the same licensing terms as Qooxdoo,
 *      please see the LICENSE file in the Qooxdoo project's top-level directory 
 *      for details.
 * 
 *    Authors:
 *      * John Spackman (john.spackman@zenesis.com)
 * 
 * ************************************************************************
 */
package com.zenesis.qx.event;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.WeakHashMap;

import org.apache.log4j.Logger;

/**
 * Manages events and listeners on arbitrary objects.
 * 
 * The listeners are stored as values in a WeakHashMap where the key is
 * the object to listen to.  The value of the map is either: a) an instance
 * of NamedEventListener, b) a small array of NamedEventListeners, or c) a 
 * HashMap where the key is the name of the event and the value is the listener.
 * 
 * The NamedEventListener's listener object is either a small array of 
 * EventListener's or a LinkedHashSet of EventListeners.
 * 
 * The reason for using Objects and reflection instead of always using HashMap
 * and LinkedHashSet is to keep the overhead down and support the common use case
 * where an object will have only a few events listened to, and each event
 * will only be listened to by a single piece of code (this is pure hypothesis!).
 * 
 * @author John Spackman [john.spackman@zenesis.com]
 */
public class EventManager {
	
	private static final Logger log = Logger.getLogger(EventManager.class);
	
	private static final int TINY_ARRAY_SIZE = 5;
	
	/*
	 * Links an event name with a listener; the listener is actually either a) null,
	 * b) an EventListener, c) and array of EventListeners, or d) a LinkedHashSet of EventListeners.
	 */
	private static final class NamedEventListener {
		public final String eventName;
		public Object listener;

		public NamedEventListener(String eventName, Object listener) {
			super();
			this.eventName = eventName;
			this.listener = listener;
		}
		
		/**
		 * Adds a listener
		 * @param newListener
		 * @throws IllegalArgumentException if the listener is added twice
		 */
		public void addListener(EventListener newListener) throws IllegalArgumentException{
			// Nothing so far? Easy.
			if (listener == null) {
				listener = newListener;
				return;
			}
			
			final Class clazz = listener.getClass();
			
			// It's an array - try and use an empty slot
			if (clazz.isArray()) {
				EventListener[] list = (EventListener[])listener;
				for (int i = 0; i < TINY_ARRAY_SIZE; i++) {
					// Free slot?  Use it
					if (list[i] == null) {
						list[i] = newListener;
						return;
						
					// Cater for using the same listener twice
					} else if (list[i] == newListener)
						throw new IllegalArgumentException("Cannot add the same listener to the same object and eventName twice");
				}
				
				// No room so upgrade to a LinkedHashSet
				LinkedHashSet<EventListener> set = new LinkedHashSet<EventListener>();
				for (int i = 0; i < TINY_ARRAY_SIZE; i++)
					set.add(list[i]);
				set.add(newListener);
				listener = set;
				
			// Already a LinkedHashSet - add to it
			} else if (clazz == LinkedHashSet.class) {
				LinkedHashSet<EventListener> set = (LinkedHashSet<EventListener>)listener;
				if (set.contains(newListener))
					throw new IllegalArgumentException("Cannot add the same listener to the same object and eventName twice");
				set.add(newListener);
				
			// Must be an EventListener instance, convert to an array 
			} else {
				assert(clazz == EventListener.class);
				if (listener == newListener)
					throw new IllegalArgumentException("Cannot add the same listener to the same object and eventName twice");
				EventListener[] list = new EventListener[TINY_ARRAY_SIZE];
				list[0] = (EventListener)listener;
				list[1] = newListener;
				listener = list;
			}
		}
		
		/**
		 * Removes a listener
		 * @param oldListener
		 * @return true if the listener existed and was removed
		 */
		public boolean removeListener(EventListener oldListener) {
			if (listener == null)
				return false;
			
			final Class clazz = listener.getClass();
			
			// It's an array - find it and remove it
			if (clazz.isArray()) {
				EventListener[] list = (EventListener[])listener;
				for (int i = 0; i < TINY_ARRAY_SIZE; i++) {
					if (list[i] == oldListener) {
						list[i] = null;
						return true;
					}
				}
				return false;
			}
				
			// Already a LinkedHashSet
			if (clazz == LinkedHashSet.class) {
				LinkedHashSet<EventListener> set = (LinkedHashSet<EventListener>)listener;
				return set.remove(oldListener);
			}
				
			// Must be an EventListener instance, convert to an array 
			assert(clazz == EventListener.class);
			if (listener != oldListener)
				return false;
			listener = null;
			return true;
		}

		/**
		 * Fires an event on the listener(s)
		 */
		public void fireEvent(Event event) {
			if (listener == null)
				return;
			
			final Class clazz = listener.getClass();
			
			// It's an array - find it and remove it
			if (clazz.isArray()) {
				EventListener[] list = (EventListener[])listener;
				for (int i = 0; i < TINY_ARRAY_SIZE; i++)
					if (list[i] != null)
						list[i].handleEvent(event);
				return;
			}
				
			// Already a LinkedHashSet
			if (clazz == LinkedHashSet.class) {
				LinkedHashSet<EventListener> set = (LinkedHashSet<EventListener>)listener;
				for (EventListener listener : set)
					listener.handleEvent(event);
				return;
			}
				
			// Must be an EventListener instance, convert to an array 
			assert(clazz == EventListener.class);
			((EventListener)listener).handleEvent(event);
		}
		
		public boolean isEmpty() {
			if (listener == null)
				return true;
			
			final Class clazz = listener.getClass();
			
			// It's an array
			if (clazz.isArray()) {
				EventListener[] list = (EventListener[])listener;
				for (int i = 0; i < TINY_ARRAY_SIZE; i++)
					if (list[i] != null)
						return false;
				return true;
			}
				
			// Already a LinkedHashSet
			if (clazz == LinkedHashSet.class) {
				LinkedHashSet<EventListener> set = (LinkedHashSet<EventListener>)listener;
				return set.isEmpty();
			}
				
			// Must be an EventListener instance 
			assert(clazz == EventListener.class);
			return true;
		}
	}
	
	private static EventManager s_instance;
	
	private WeakHashMap<Object, Object> listeners = new WeakHashMap<Object, Object>();

	/**
	 * Constructor; the first instance of EventManager will become the global default
	 */
	public EventManager() {
		this(true);
	}

	/**
	 * Constructor; the first instance of EventManager will become the global default only
	 * if setGlobal is true
	 * @param setGlobal whether to make this instance the global one
	 */
	public EventManager(boolean setGlobal) {
		super();
		if (setGlobal) {
			if (s_instance != null)
				log.warn("Replacing global instance of EventManager");
			s_instance = this;
		}
	}

	/**
	 * Adds an event listener
	 * @param keyObject
	 * @param eventName
	 * @param listener
	 * @throws {@link IllegalArgumentException} if a listener is added twice
	 * @return true if the event was added
	 */
	public boolean addListener(Object keyObject, String eventName, EventListener listener) throws IllegalArgumentException{
		if (!supportsEvent(keyObject, eventName))
			return false;
		
		Object current = listeners.get(keyObject);
		
		// If the object is not yet known, then create a new NEL and return
		if (current == null) {
			NamedEventListener nel = new NamedEventListener(eventName, listener);
			listeners.put(keyObject, nel);
			return true;
		}
		
		final Class clazz = current.getClass();
		
		// A NamedEventListener?  Then we've found it
		if (clazz == NamedEventListener.class) {
			NamedEventListener nel = (NamedEventListener)current;
			if (nel.eventName.equals(eventName))
				nel.addListener(listener);
			else {
				NamedEventListener[] nels = new NamedEventListener[TINY_ARRAY_SIZE];
				nels[0] = nel;
				nels[1] = new NamedEventListener(eventName, listener);
				listeners.put(keyObject, nels);
			}
			return true;
		}

		// If there is an array, it's an array of NamedEventListeners
		if (clazz.isArray()){
			NamedEventListener[] nels = (NamedEventListener[])current;
			
			// Look for a NamedEventListener for the eventName, or a free slot in the array
			int index = 0;
			int freeIndex = -1;
			while (index < TINY_ARRAY_SIZE) {
				if (nels[index] == null) {
					if (freeIndex < 0)
						freeIndex = index;
				} else if (nels[index].eventName.equals(eventName))
					break;
				index++;
			}
			
			// Found a NamedEventListener?
			if (index < TINY_ARRAY_SIZE) {
				nels[index].addListener(listener);
			
			// Found a free slot?
			} else if (freeIndex > -1) {
				NamedEventListener nel = nels[freeIndex] = new NamedEventListener(eventName, null);
				nel.addListener(listener);
			
			// The array is full - convert to a HashMap
			} else {
				// Convert to a map
				HashMap<String, NamedEventListener> map = new HashMap<String, NamedEventListener>();
				for (int i = 0; i < TINY_ARRAY_SIZE; i++)
					map.put(nels[i].eventName, nels[i]);
				
				// Add the new NamedEventListener
				map.put(eventName, new NamedEventListener(eventName, listener));
				
				// Replace the array with the map
				listeners.put(keyObject, map);
			}
			
			return true;
		}
		
		// By elimination, it must be a HashMap
		assert(current.getClass() == HashMap.class);
		HashMap<String, NamedEventListener> map = (HashMap<String, NamedEventListener>)current;
		NamedEventListener nel = map.get(eventName);
		if (nel == null)
			map.put(eventName, new NamedEventListener(eventName, listener));
		else
			nel.addListener(listener);
		
		return true;
	}
	
	/**
	 * Removes a listener from an object and eventName
	 * @param keyObject
	 * @param eventName
	 * @param listener
	 * @return
	 */
	public boolean removeListener(Object keyObject, String eventName, EventListener listener) {
		Object current = listeners.get(keyObject);
		if (current == null)
			return false;
		
		final Class clazz = current.getClass();
		
		// A NamedEventListener?  Then check the eventName 
		if (clazz == NamedEventListener.class) {
			NamedEventListener nel = (NamedEventListener)current;
			if (!nel.eventName.equals(eventName))
				return false;
			return nel.removeListener(listener);
		}

		// If there is an array, it's an array of NamedEventListeners
		if (clazz.isArray()){
			NamedEventListener[] nels = (NamedEventListener[])current;
			
			// Look for a NamedEventListener for the eventName
			for (int i = 0; i < TINY_ARRAY_SIZE; i++)
				if (nels[i].eventName.equals(eventName))
					return nels[i].removeListener(listener);
			
			return false;
		}
		
		// By elimination, it must be a HashMap
		assert(current.getClass() == HashMap.class);
		HashMap<String, NamedEventListener> map = (HashMap<String, NamedEventListener>)current;
		NamedEventListener nel = map.get(eventName);
		if (nel == null)
			return false;
		return nel.removeListener(listener);
	}
	
	/**
	 * Detects whether the object supports the given event name; by default, all objects
	 * are considered to support events.
	 * @param obj
	 * @param eventName
	 * @return
	 */
	public boolean supportsEvent(Object obj, String eventName) {
		if (obj instanceof Eventable) {
			Eventable ev = (Eventable)obj;
			return ev.supportsEvent(eventName);
		}
		
		return true;
	}

	/**
	 * Fires an event on the object
	 * @param obj
	 * @param eventName
	 */
	public void fireEvent(Object obj, String eventName) {
		fireDataEvent(obj, eventName, null);
	}

	/**
	 * Fires a data event on the object
	 * @param obj
	 * @param eventName
	 * @param data
	 */
	public void fireDataEvent(Object keyObject, String eventName, Object data) {
		Object current = listeners.get(keyObject);
		if (current == null)
			return;
		
		final Class clazz = current.getClass();
		
		// A NamedEventListener?  Then check the eventName 
		if (clazz == NamedEventListener.class) {
			NamedEventListener nel = (NamedEventListener)current;
			if (!nel.eventName.equals(eventName))
				return;
			nel.fireEvent(new Event(eventName, keyObject, keyObject, data));
			return;
		}

		// If there is an array, it's an array of NamedEventListeners
		if (clazz.isArray()){
			NamedEventListener[] nels = (NamedEventListener[])current;
			Event event = null;
			
			// Look for a NamedEventListener for the eventName
			for (int i = 0; i < TINY_ARRAY_SIZE; i++)
				if (nels[i] != null && nels[i].eventName.equals(eventName)) {
					if (event == null)
						event = new Event(eventName, keyObject, keyObject, data);
					nels[i].fireEvent(event);
				}
			
			return;
		}
		
		// By elimination, it must be a HashMap
		assert(current.getClass() == HashMap.class);
		HashMap<String, NamedEventListener> map = (HashMap<String, NamedEventListener>)current;
		NamedEventListener nel = map.get(eventName);
		if (nel == null)
			return;
		nel.fireEvent(new Event(eventName, keyObject, keyObject, data));
	}

	/**
	 * Tests whether there are eny event listeners on any object
	 * @return
	 */
	public boolean isEmpty() {
		if (listeners.isEmpty())
			return true;
		for (Object current : listeners.values()) {
			final Class clazz = current.getClass();
			
			// A NamedEventListener?  Then check the eventName 
			if (clazz == NamedEventListener.class) {
				NamedEventListener nel = (NamedEventListener)current;
				if (!nel.isEmpty())
					return false;
				continue;
			}

			// If there is an array, it's an array of NamedEventListeners
			if (clazz.isArray()){
				NamedEventListener[] nels = (NamedEventListener[])current;
				
				// Look for a NamedEventListener for the eventName
				for (int i = 0; i < TINY_ARRAY_SIZE; i++)
					if (nels[i] != null && !nels[i].isEmpty())
						return false;
				
				continue;
			}
			
			// By elimination, it must be a HashMap
			assert(current.getClass() == HashMap.class);
			HashMap<String, NamedEventListener> map = (HashMap<String, NamedEventListener>)current;
			for (NamedEventListener nel : map.values())
				if (!nel.isEmpty())
					return false;
		}
		return true;
	}
	
	/**
	 * Returns the default global instance
	 * @return
	 */
	public static EventManager getInstance() {
		return s_instance;
	}
}
